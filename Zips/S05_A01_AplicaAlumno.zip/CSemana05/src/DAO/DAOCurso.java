package DAO;

import Modelo.Curso;
import java.util.ArrayList;

public class DAOCurso {

    // ArrayList que almacenará los cursos
    private final ArrayList<Curso> listaCursos;

    public DAOCurso() {
        listaCursos = new ArrayList<>();
    }

    // AGREGAR
    public void agregar(Curso curso) {
        listaCursos.add(curso);
    }

    // LISTAR
    public ArrayList<Curso> listar() {
        return listaCursos;
    }

    // BUSCAR POR CÓDIGO
    public Curso buscarPorCodigo(int codigo) {
        for (int i = 0; i < listaCursos.size(); i++) {
            Curso c = listaCursos.get(i);
            if (c.getCodigo() == codigo) {
                return c;
            }
        }
        return null;
    }

    // BUSCAR POR NOMBRE (coincidencia parcial)
    public ArrayList<Curso> buscarPorNombre(String nombre) {
        ArrayList<Curso> resultado = new ArrayList<>();
        for (Curso c : listaCursos) {
            if (c.getNombre().toLowerCase().contains(nombre.toLowerCase())) {
                resultado.add(c);
            }
        }
        return resultado;
    }

    // BUSCAR POR DOCENTE (coincidencia parcial)
    public ArrayList<Curso> buscarPorDocente(String docente) {
        ArrayList<Curso> resultado = new ArrayList<>();
        for (Curso c : listaCursos) {
            if (c.getDocente().toLowerCase().contains(docente.toLowerCase())) {
                resultado.add(c);
            }
        }
        return resultado;
    }

    // MODIFICAR (el código no se modifica)
    public boolean modificar(int codigo, String nombre, int creditos, String docente) {
        Curso c = buscarPorCodigo(codigo);
        if (c == null) {
            return false;
        }
        c.setNombre(nombre);
        c.setCreditos(creditos);
        c.setDocente(docente);
        return true;
    }

    // ELIMINAR
    public boolean eliminar(int codigo) {
        for (int i = 0; i < listaCursos.size(); i++) {
            if (listaCursos.get(i).getCodigo() == codigo) {
                listaCursos.remove(i);
                return true;
            }
        }
        return false;
    }

    public boolean existeCodigo(int codigo) {
        return buscarPorCodigo(codigo) != null;
    }

    public boolean hayCursos() {
        return !listaCursos.isEmpty();
    }
}
