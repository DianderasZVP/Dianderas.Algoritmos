package DAO;

import Modelo.Estudiante;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class DAOEstudiante {

    // ArrayList que almacenará los estudiantes
    private final ArrayList<Estudiante> listaEstudiantes;

    public DAOEstudiante() {
        listaEstudiantes = new ArrayList<>();
    }

    // 1. AGREGAR
    public void agregar(Estudiante estudiante) {
        listaEstudiantes.add(estudiante);
    }

    // 2. LISTAR
    public ArrayList<Estudiante> listar() {
        return listaEstudiantes;
    }

    // 3. BUSCAR POR CÓDIGO
    public Estudiante buscarPorCodigo(int codigo) {
        for (int i = 0; i < listaEstudiantes.size(); i++) {
            Estudiante e = listaEstudiantes.get(i);
            if (e.getCodigo() == codigo) {
                return e;
            }
        }
        return null;
    }

    // BUSCAR POR DNI
    public Estudiante buscarPorDni(String dni) {
        for (Estudiante e : listaEstudiantes) {
            if (e.getDni().equals(dni)) {
                return e;
            }
        }
        return null;
    }

    // BUSCAR POR APELLIDOS (coincidencia parcial, sin distinguir mayúsculas)
    public ArrayList<Estudiante> buscarPorApellidos(String apellidos) {
        ArrayList<Estudiante> resultado = new ArrayList<>();
        for (Estudiante e : listaEstudiantes) {
            if (e.getApellidos().toLowerCase().contains(apellidos.toLowerCase())) {
                resultado.add(e);
            }
        }
        return resultado;
    }

    // 4. MODIFICAR (el código no se modifica)
    public boolean modificar(int codigo, String nombres, String apellidos,
            int edad, String carrera, int semestre) {
        Estudiante e = buscarPorCodigo(codigo);
        if (e == null) {
            return false;
        }
        e.setNombres(nombres);
        e.setApellidos(apellidos);
        e.setEdad(edad);
        e.setCarrera(carrera);
        e.setSemestre(semestre);
        return true;
    }

    // 5. ELIMINAR
    public boolean eliminar(int codigo) {
        for (int i = 0; i < listaEstudiantes.size(); i++) {
            if (listaEstudiantes.get(i).getCodigo() == codigo) {
                listaEstudiantes.remove(i);
                return true;
            }
        }
        return false;
    }

    // VALIDACIONES
    public boolean existeCodigo(int codigo) {
        return buscarPorCodigo(codigo) != null;
    }

    public boolean existeDni(String dni) {
        return buscarPorDni(dni) != null;
    }

    public boolean hayEstudiantes() {
        return !listaEstudiantes.isEmpty();
    }

    // RANKING: copia de la lista ordenada por promedio (mayor a menor)
    public ArrayList<Estudiante> ranking() {
        ArrayList<Estudiante> copia = new ArrayList<>();
        for (Estudiante e : listaEstudiantes) {
            if (e.tieneMatriculas()) {
                copia.add(e);
            }
        }
        Collections.sort(copia, new Comparator<Estudiante>() {
            @Override
            public int compare(Estudiante a, Estudiante b) {
                return Double.compare(b.calcularPromedio(), a.calcularPromedio());
            }
        });
        return copia;
    }

    // FILTRAR POR CARRERA
    public ArrayList<Estudiante> listarPorCarrera(String carrera) {
        ArrayList<Estudiante> resultado = new ArrayList<>();
        for (Estudiante e : listaEstudiantes) {
            if (e.getCarrera().equalsIgnoreCase(carrera)) {
                resultado.add(e);
            }
        }
        return resultado;
    }

    // ESTUDIANTES CON CURSOS DESAPROBADOS
    public ArrayList<Estudiante> listarDesaprobados() {
        ArrayList<Estudiante> resultado = new ArrayList<>();
        for (Estudiante e : listaEstudiantes) {
            if (e.tieneDesaprobados()) {
                resultado.add(e);
            }
        }
        return resultado;
    }

    // ESTUDIANTE CON MAYOR PROMEDIO
    public Estudiante mejorPromedio() {
        Estudiante mejor = null;
        for (Estudiante e : listaEstudiantes) {
            if (e.tieneMatriculas()
                    && (mejor == null || e.calcularPromedio() > mejor.calcularPromedio())) {
                mejor = e;
            }
        }
        return mejor;
    }
}
