package DAO;

import Modelo.Curso;
import Modelo.Estudiante;
import Modelo.Matricula;
import java.util.ArrayList;

public class DAOMatricula {

    // ArrayList general de matrículas
    private final ArrayList<Matricula> listaMatriculas;

    public DAOMatricula() {
        listaMatriculas = new ArrayList<>();
    }

    // REGISTRAR: guarda en la lista general y en la lista del estudiante
    public void agregar(Estudiante estudiante, Curso curso, double nota) {
        Matricula m = new Matricula(estudiante, curso, nota);
        listaMatriculas.add(m);
        estudiante.agregarMatricula(m);
    }

    // LISTAR
    public ArrayList<Matricula> listar() {
        return listaMatriculas;
    }

    // BUSCAR por estudiante y curso
    public Matricula buscar(int codEstudiante, int codCurso) {
        for (int i = 0; i < listaMatriculas.size(); i++) {
            Matricula m = listaMatriculas.get(i);
            if (m.getEstudiante().getCodigo() == codEstudiante
                    && m.getCurso().getCodigo() == codCurso) {
                return m;
            }
        }
        return null;
    }

    // MODIFICAR NOTA
    public boolean modificarNota(int codEstudiante, int codCurso, double nuevaNota) {
        Matricula m = buscar(codEstudiante, codCurso);
        if (m == null) {
            return false;
        }
        m.setNotaFinal(nuevaNota);
        return true;
    }

    // ELIMINAR: quita de ambas listas
    public boolean eliminar(int codEstudiante, int codCurso) {
        Matricula m = buscar(codEstudiante, codCurso);
        if (m == null) {
            return false;
        }
        m.getEstudiante().quitarMatricula(m);
        listaMatriculas.remove(m);
        return true;
    }

    // ¿El estudiante tiene matrículas?
    public boolean existenPorEstudiante(int codEstudiante) {
        for (Matricula m : listaMatriculas) {
            if (m.getEstudiante().getCodigo() == codEstudiante) {
                return true;
            }
        }
        return false;
    }

    // ¿El curso tiene matrículas asociadas?
    public boolean existenPorCurso(int codCurso) {
        for (Matricula m : listaMatriculas) {
            if (m.getCurso().getCodigo() == codCurso) {
                return true;
            }
        }
        return false;
    }

    public boolean hayMatriculas() {
        return !listaMatriculas.isEmpty();
    }
}
