package Modelo;

public class Curso {

    // Atributos
    private int codigo;
    private String nombre;
    private int creditos;
    private String docente;

    // Constructor vacío
    public Curso() {
    }

    // Constructor con parámetros
    public Curso(int codigo, String nombre, int creditos, String docente) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.creditos = creditos;
        this.docente = docente;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCreditos() {
        return creditos;
    }

    public void setCreditos(int creditos) {
        this.creditos = creditos;
    }

    public String getDocente() {
        return docente;
    }

    public void setDocente(String docente) {
        this.docente = docente;
    }

    @Override
    public String toString() {
        return "Codigo: " + codigo
                + " | Curso: " + nombre
                + " | Creditos: " + creditos
                + " | Docente: " + docente;
    }
}
