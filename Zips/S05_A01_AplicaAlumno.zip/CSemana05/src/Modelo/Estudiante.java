package Modelo;

import java.util.ArrayList;

public class Estudiante {

    // Atributos
    private int codigo;
    private String dni;
    private String nombres;
    private String apellidos;
    private int edad;
    private String carrera;
    private int semestre;

    // Composición: un estudiante tiene varias matrículas
    private final ArrayList<Matricula> matriculas;

    // Constructor vacío
    public Estudiante() {
        matriculas = new ArrayList<>();
    }

    // Constructor con parámetros
    public Estudiante(int codigo, String dni, String nombres, String apellidos,
            int edad, String carrera, int semestre) {
        this.codigo = codigo;
        this.dni = dni;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.edad = edad;
        this.carrera = carrera;
        this.semestre = semestre;
        this.matriculas = new ArrayList<>();
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public int getSemestre() {
        return semestre;
    }

    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }

    public ArrayList<Matricula> getMatriculas() {
        return matriculas;
    }

    // ----- Métodos de apoyo sobre las matrículas del estudiante -----
    public void agregarMatricula(Matricula matricula) {
        matriculas.add(matricula);
    }

    public void quitarMatricula(Matricula matricula) {
        matriculas.remove(matricula);
    }

    public boolean tieneMatriculas() {
        return !matriculas.isEmpty();
    }

    // Promedio de las notas finales (0 si no tiene matrículas)
    public double calcularPromedio() {
        if (matriculas.isEmpty()) {
            return 0;
        }
        double suma = 0;
        for (Matricula m : matriculas) {
            suma += m.getNotaFinal();
        }
        return suma / matriculas.size();
    }

    // Indica si tiene al menos un curso desaprobado
    public boolean tieneDesaprobados() {
        for (Matricula m : matriculas) {
            if (m.getEstado().equals("DESAPROBADO")) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        return "Codigo: " + codigo
                + " | DNI: " + dni
                + " | Nombres: " + nombres
                + " | Apellidos: " + apellidos
                + " | Edad: " + edad
                + " | Carrera: " + carrera
                + " | Semestre: " + semestre;
    }
}
