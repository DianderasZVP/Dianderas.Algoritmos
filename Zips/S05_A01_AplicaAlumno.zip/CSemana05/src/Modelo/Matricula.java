package Modelo;

public class Matricula {

    // Composición: una matrícula relaciona un estudiante con un curso
    private Estudiante estudiante;
    private Curso curso;
    private double notaFinal;

    // Constructor vacío
    public Matricula() {
    }

    // Constructor con parámetros
    public Matricula(Estudiante estudiante, Curso curso, double notaFinal) {
        this.estudiante = estudiante;
        this.curso = curso;
        this.notaFinal = notaFinal;
    }

    public Estudiante getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(Estudiante estudiante) {
        this.estudiante = estudiante;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    public double getNotaFinal() {
        return notaFinal;
    }

    public void setNotaFinal(double notaFinal) {
        this.notaFinal = notaFinal;
    }

    // El estado académico se determina automáticamente según la nota
    public String getEstado() {
        if (notaFinal >= 13) {
            return "APROBADO";
        } else if (notaFinal >= 11) {
            return "RECUPERACION";
        } else {
            return "DESAPROBADO";
        }
    }

    @Override
    public String toString() {
        return "Estudiante: " + estudiante.getNombres() + " " + estudiante.getApellidos()
                + " | Curso: " + curso.getNombre()
                + " | Nota: " + String.format("%.2f", notaFinal)
                + " | Estado: " + getEstado();
    }
}
