package Vista;

import DAO.DAOCurso;
import DAO.DAOEstudiante;
import DAO.DAOMatricula;
import Modelo.Curso;
import Modelo.Estudiante;
import Modelo.Matricula;
import java.util.ArrayList;
import java.util.Scanner;

public class AplicaSistema {

    // Scanner para ingresar datos
    static Scanner teclado = new Scanner(System.in);

    // Objetos DAO
    static DAOEstudiante daoEstudiante = new DAOEstudiante();
    static DAOCurso daoCurso = new DAOCurso();
    static DAOMatricula daoMatricula = new DAOMatricula();

    public static void main(String[] args) {
        // cargarDatosPrueba();  // Quite los // para iniciar con datos de ejemplo
        menu();
    }

    // =====================================================================
    // MENÚ PRINCIPAL
    // =====================================================================
    public static void menu() {
        int op;
        do {
            System.out.println("\n====================================================");
            System.out.println("                 SISTEMA ACADEMICO");
            System.out.println("====================================================");
            System.out.println("ESTUDIANTES");
            System.out.println("[1]  Registrar estudiante");
            System.out.println("[2]  Listar estudiantes");
            System.out.println("[3]  Buscar estudiante");
            System.out.println("[4]  Modificar estudiante");
            System.out.println("[5]  Eliminar estudiante");
            System.out.println("CURSOS");
            System.out.println("[6]  Registrar curso");
            System.out.println("[7]  Listar cursos");
            System.out.println("[8]  Buscar curso");
            System.out.println("[9]  Modificar curso");
            System.out.println("[10] Eliminar curso");
            System.out.println("MATRICULAS");
            System.out.println("[11] Registrar matricula");
            System.out.println("[12] Listar matriculas");
            System.out.println("[13] Consultar cursos de estudiante");
            System.out.println("[14] Modificar nota");
            System.out.println("[15] Eliminar matricula");
            System.out.println("REPORTES");
            System.out.println("[16] Promedio de estudiante");
            System.out.println("[17] Ranking academico");
            System.out.println("[18] Estudiantes por carrera");
            System.out.println("[19] Estudiantes desaprobados");
            System.out.println("[20] Mejor promedio");
            System.out.println("[21] Salir");
            System.out.println("====================================================");
            op = leerEntero("Ingrese una opcion: ");

            switch (op) {
                case 1:
                    registrarEstudiante();
                    break;
                case 2:
                    listarEstudiantes();
                    break;
                case 3:
                    buscarEstudiante();
                    break;
                case 4:
                    modificarEstudiante();
                    break;
                case 5:
                    eliminarEstudiante();
                    break;
                case 6:
                    registrarCurso();
                    break;
                case 7:
                    listarCursos();
                    break;
                case 8:
                    buscarCurso();
                    break;
                case 9:
                    modificarCurso();
                    break;
                case 10:
                    eliminarCurso();
                    break;
                case 11:
                    registrarMatricula();
                    break;
                case 12:
                    listarMatriculas();
                    break;
                case 13:
                    consultarCursosEstudiante();
                    break;
                case 14:
                    modificarNota();
                    break;
                case 15:
                    eliminarMatricula();
                    break;
                case 16:
                    promedioEstudiante();
                    break;
                case 17:
                    rankingAcademico();
                    break;
                case 18:
                    estudiantesPorCarrera();
                    break;
                case 19:
                    estudiantesDesaprobados();
                    break;
                case 20:
                    mejorPromedio();
                    break;
                case 21:
                    System.out.println("\nPrograma finalizado...");
                    break;
                default:
                    System.out.println("\nOpcion incorrecta.");
            }
        } while (op != 21);
    }

    // =====================================================================
    // MÉTODOS DE LECTURA CON VALIDACIÓN
    // =====================================================================
    public static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String linea = teclado.nextLine().trim();
            try {
                return Integer.parseInt(linea);
            } catch (NumberFormatException e) {
                System.out.println("Debe ingresar un numero entero valido.");
            }
        }
    }

    public static int leerEnteroPositivo(String mensaje) {
        int n;
        do {
            n = leerEntero(mensaje);
            if (n <= 0) {
                System.out.println("El valor debe ser mayor que cero.");
            }
        } while (n <= 0);
        return n;
    }

    public static double leerNota(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String linea = teclado.nextLine().trim().replace(',', '.');
            try {
                double nota = Double.parseDouble(linea);
                if (nota >= 0 && nota <= 20) {
                    return nota;
                }
                System.out.println("La nota debe estar entre 0 y 20.");
            } catch (NumberFormatException e) {
                System.out.println("Debe ingresar un numero valido.");
            }
        }
    }

    public static String leerTexto(String mensaje) {
        String texto;
        do {
            System.out.print(mensaje);
            texto = teclado.nextLine().trim();
            if (texto.isEmpty()) {
                System.out.println("El campo no puede estar vacio.");
            }
        } while (texto.isEmpty());
        return texto;
    }

    public static String leerDni(String mensaje) {
        String dni;
        do {
            dni = leerTexto(mensaje);
            if (!dni.matches("\\d{8}")) {
                System.out.println("El DNI debe tener 8 digitos numericos.");
            }
        } while (!dni.matches("\\d{8}"));
        return dni;
    }

    // =====================================================================
    // GESTIÓN DE ESTUDIANTES
    // =====================================================================

    // 1. REGISTRAR ESTUDIANTE
    public static void registrarEstudiante() {
        System.out.println("\n===== REGISTRAR ESTUDIANTE =====");
        int codigo = leerEnteroPositivo("Ingrese codigo: ");
        if (daoEstudiante.existeCodigo(codigo)) {
            System.out.println("\nEl codigo ya existe.");
            return;
        }
        String dni = leerDni("Ingrese DNI: ");
        if (daoEstudiante.existeDni(dni)) {
            System.out.println("\nEl DNI ya esta registrado.");
            return;
        }
        String nombres = leerTexto("Ingrese nombres: ");
        String apellidos = leerTexto("Ingrese apellidos: ");
        int edad = leerEnteroPositivo("Ingrese edad: ");
        String carrera = leerTexto("Ingrese carrera: ");
        int semestre = leerEnteroPositivo("Ingrese semestre: ");

        daoEstudiante.agregar(new Estudiante(codigo, dni, nombres, apellidos, edad, carrera, semestre));
        System.out.println("\nEstudiante registrado correctamente.");
    }

    // 2. LISTAR ESTUDIANTES
    public static void listarEstudiantes() {
        System.out.println("\n===== LISTADO DE ESTUDIANTES =====");
        if (!daoEstudiante.hayEstudiantes()) {
            System.out.println("No existen estudiantes registrados.");
            return;
        }
        for (Estudiante e : daoEstudiante.listar()) {
            System.out.println(e);
        }
        System.out.println("\nTotal de estudiantes: " + daoEstudiante.listar().size());
    }

    // 3. BUSCAR ESTUDIANTE (por código, DNI o apellidos)
    public static void buscarEstudiante() {
        System.out.println("\n===== BUSCAR ESTUDIANTE =====");
        System.out.println("[1] Por codigo");
        System.out.println("[2] Por DNI");
        System.out.println("[3] Por apellidos");
        int op = leerEntero("Ingrese una opcion: ");

        switch (op) {
            case 1:
                int codigo = leerEntero("Ingrese codigo: ");
                Estudiante porCodigo = daoEstudiante.buscarPorCodigo(codigo);
                mostrarEstudianteEncontrado(porCodigo);
                break;
            case 2:
                String dni = leerTexto("Ingrese DNI: ");
                Estudiante porDni = daoEstudiante.buscarPorDni(dni);
                mostrarEstudianteEncontrado(porDni);
                break;
            case 3:
                String apellidos = leerTexto("Ingrese apellidos: ");
                ArrayList<Estudiante> resultado = daoEstudiante.buscarPorApellidos(apellidos);
                if (resultado.isEmpty()) {
                    System.out.println("\nNo se encontraron estudiantes.");
                } else {
                    System.out.println("\nEstudiantes encontrados: " + resultado.size());
                    for (Estudiante e : resultado) {
                        System.out.println(e);
                    }
                }
                break;
            default:
                System.out.println("\nOpcion incorrecta.");
        }
    }

    private static void mostrarEstudianteEncontrado(Estudiante e) {
        if (e == null) {
            System.out.println("\nEstudiante no encontrado.");
        } else {
            System.out.println("\nEstudiante encontrado:");
            System.out.println(e);
        }
    }

    // 4. MODIFICAR ESTUDIANTE
    public static void modificarEstudiante() {
        System.out.println("\n===== MODIFICAR ESTUDIANTE =====");
        int codigo = leerEntero("Ingrese codigo del estudiante: ");
        Estudiante e = daoEstudiante.buscarPorCodigo(codigo);
        if (e == null) {
            System.out.println("\nEstudiante no encontrado.");
            return;
        }
        System.out.println("\nDatos actuales:");
        System.out.println(e);
        System.out.println("\nIngrese los nuevos datos (el codigo no se modifica):");
        String nombres = leerTexto("Nombres: ");
        String apellidos = leerTexto("Apellidos: ");
        int edad = leerEnteroPositivo("Edad: ");
        String carrera = leerTexto("Carrera: ");
        int semestre = leerEnteroPositivo("Semestre: ");

        if (daoEstudiante.modificar(codigo, nombres, apellidos, edad, carrera, semestre)) {
            System.out.println("\nEstudiante modificado correctamente.");
        } else {
            System.out.println("\nNo se pudo modificar el estudiante.");
        }
    }

    // 5. ELIMINAR ESTUDIANTE
    public static void eliminarEstudiante() {
        System.out.println("\n===== ELIMINAR ESTUDIANTE =====");
        int codigo = leerEntero("Ingrese codigo del estudiante: ");
        Estudiante e = daoEstudiante.buscarPorCodigo(codigo);
        if (e == null) {
            System.out.println("\nEstudiante no encontrado.");
            return;
        }
        System.out.println("\nEstudiante encontrado:");
        System.out.println(e);

        // Verificar si tiene matrículas registradas
        if (daoMatricula.existenPorEstudiante(codigo)) {
            System.out.println("\nADVERTENCIA: el estudiante tiene matriculas registradas.");
            System.out.println("Elimine primero sus matriculas (opcion 15) para poder eliminarlo.");
            return;
        }
        String respuesta = leerTexto("\nEsta seguro de eliminarlo? (S/N): ");
        if (respuesta.equalsIgnoreCase("S")) {
            if (daoEstudiante.eliminar(codigo)) {
                System.out.println("\nEstudiante eliminado correctamente.");
            }
        } else {
            System.out.println("\nOperacion cancelada.");
        }
    }

    // =====================================================================
    // GESTIÓN DE CURSOS
    // =====================================================================

    // 6. REGISTRAR CURSO
    public static void registrarCurso() {
        System.out.println("\n===== REGISTRAR CURSO =====");
        int codigo = leerEnteroPositivo("Ingrese codigo del curso: ");
        if (daoCurso.existeCodigo(codigo)) {
            System.out.println("\nEl codigo del curso ya existe.");
            return;
        }
        String nombre = leerTexto("Ingrese nombre del curso: ");
        int creditos = leerEnteroPositivo("Ingrese creditos: ");
        String docente = leerTexto("Ingrese docente: ");

        daoCurso.agregar(new Curso(codigo, nombre, creditos, docente));
        System.out.println("\nCurso registrado correctamente.");
    }

    // 7. LISTAR CURSOS
    public static void listarCursos() {
        System.out.println("\n===== LISTADO DE CURSOS =====");
        if (!daoCurso.hayCursos()) {
            System.out.println("No existen cursos registrados.");
            return;
        }
        for (Curso c : daoCurso.listar()) {
            System.out.println(c);
        }
        System.out.println("\nTotal de cursos: " + daoCurso.listar().size());
    }

    // 8. BUSCAR CURSO (por código, nombre o docente)
    public static void buscarCurso() {
        System.out.println("\n===== BUSCAR CURSO =====");
        System.out.println("[1] Por codigo");
        System.out.println("[2] Por nombre");
        System.out.println("[3] Por docente");
        int op = leerEntero("Ingrese una opcion: ");

        ArrayList<Curso> resultado = new ArrayList<>();
        switch (op) {
            case 1:
                int codigo = leerEntero("Ingrese codigo: ");
                Curso c = daoCurso.buscarPorCodigo(codigo);
                if (c != null) {
                    resultado.add(c);
                }
                break;
            case 2:
                resultado = daoCurso.buscarPorNombre(leerTexto("Ingrese nombre: "));
                break;
            case 3:
                resultado = daoCurso.buscarPorDocente(leerTexto("Ingrese docente: "));
                break;
            default:
                System.out.println("\nOpcion incorrecta.");
                return;
        }
        if (resultado.isEmpty()) {
            System.out.println("\nCurso no encontrado.");
        } else {
            System.out.println("\nCursos encontrados: " + resultado.size());
            for (Curso curso : resultado) {
                System.out.println(curso);
            }
        }
    }

    // 9. MODIFICAR CURSO
    public static void modificarCurso() {
        System.out.println("\n===== MODIFICAR CURSO =====");
        int codigo = leerEntero("Ingrese codigo del curso: ");
        Curso c = daoCurso.buscarPorCodigo(codigo);
        if (c == null) {
            System.out.println("\nCurso no encontrado.");
            return;
        }
        System.out.println("\nDatos actuales:");
        System.out.println(c);
        System.out.println("\nIngrese los nuevos datos (el codigo no se modifica):");
        String nombre = leerTexto("Nombre: ");
        int creditos = leerEnteroPositivo("Creditos: ");
        String docente = leerTexto("Docente: ");

        if (daoCurso.modificar(codigo, nombre, creditos, docente)) {
            System.out.println("\nCurso modificado correctamente.");
        } else {
            System.out.println("\nNo se pudo modificar el curso.");
        }
    }

    // 10. ELIMINAR CURSO
    public static void eliminarCurso() {
        System.out.println("\n===== ELIMINAR CURSO =====");
        int codigo = leerEntero("Ingrese codigo del curso: ");
        Curso c = daoCurso.buscarPorCodigo(codigo);
        if (c == null) {
            System.out.println("\nCurso no encontrado.");
            return;
        }
        System.out.println("\nCurso encontrado:");
        System.out.println(c);

        // Verificar si existen matrículas asociadas
        if (daoMatricula.existenPorCurso(codigo)) {
            System.out.println("\nADVERTENCIA: el curso tiene matriculas asociadas.");
            System.out.println("Elimine primero esas matriculas (opcion 15) para poder eliminarlo.");
            return;
        }
        String respuesta = leerTexto("\nEsta seguro de eliminarlo? (S/N): ");
        if (respuesta.equalsIgnoreCase("S")) {
            if (daoCurso.eliminar(codigo)) {
                System.out.println("\nCurso eliminado correctamente.");
            }
        } else {
            System.out.println("\nOperacion cancelada.");
        }
    }

    // =====================================================================
    // GESTIÓN DE MATRÍCULAS
    // =====================================================================

    // 11. REGISTRAR MATRÍCULA
    public static void registrarMatricula() {
        System.out.println("\n===== REGISTRAR MATRICULA =====");
        int codEstudiante = leerEntero("Ingrese codigo del estudiante: ");
        Estudiante estudiante = daoEstudiante.buscarPorCodigo(codEstudiante);
        if (estudiante == null) {
            System.out.println("\nEl estudiante no existe.");
            return;
        }
        int codCurso = leerEntero("Ingrese codigo del curso: ");
        Curso curso = daoCurso.buscarPorCodigo(codCurso);
        if (curso == null) {
            System.out.println("\nEl curso no existe.");
            return;
        }
        if (daoMatricula.buscar(codEstudiante, codCurso) != null) {
            System.out.println("\nEl estudiante ya esta matriculado en ese curso.");
            return;
        }
        double nota = leerNota("Ingrese nota final (0-20): ");

        daoMatricula.agregar(estudiante, curso, nota);
        Matricula m = daoMatricula.buscar(codEstudiante, codCurso);
        System.out.println("\nMatricula registrada correctamente.");
        System.out.println(m);
    }

    // 12. LISTAR MATRÍCULAS
    public static void listarMatriculas() {
        System.out.println("\n===== LISTADO DE MATRICULAS =====");
        if (!daoMatricula.hayMatriculas()) {
            System.out.println("No existen matriculas registradas.");
            return;
        }
        for (Matricula m : daoMatricula.listar()) {
            System.out.println(m);
        }
        System.out.println("\nTotal de matriculas: " + daoMatricula.listar().size());
    }

    // 13. CONSULTAR CURSOS DE UN ESTUDIANTE
    public static void consultarCursosEstudiante() {
        System.out.println("\n===== CURSOS DEL ESTUDIANTE =====");
        int codigo = leerEntero("Ingrese codigo del estudiante: ");
        Estudiante e = daoEstudiante.buscarPorCodigo(codigo);
        if (e == null) {
            System.out.println("\nEstudiante no encontrado.");
            return;
        }
        System.out.println("\nEstudiante: " + e.getNombres() + " " + e.getApellidos());
        System.out.println("Carrera: " + e.getCarrera() + " | Semestre: " + e.getSemestre());
        if (!e.tieneMatriculas()) {
            System.out.println("\nEl estudiante no tiene cursos matriculados.");
            return;
        }
        System.out.println("\nCursos matriculados:");
        int n = 1;
        for (Matricula m : e.getMatriculas()) {
            System.out.println(n + ". " + m.getCurso().getNombre()
                    + " | Nota: " + String.format("%.2f", m.getNotaFinal())
                    + " | Estado: " + m.getEstado());
            n++;
        }
    }

    // 14. MODIFICAR NOTA
    public static void modificarNota() {
        System.out.println("\n===== MODIFICAR NOTA =====");
        int codEstudiante = leerEntero("Ingrese codigo del estudiante: ");
        int codCurso = leerEntero("Ingrese codigo del curso: ");
        Matricula m = daoMatricula.buscar(codEstudiante, codCurso);
        if (m == null) {
            System.out.println("\nMatricula no encontrada.");
            return;
        }
        System.out.println("\nMatricula actual:");
        System.out.println(m);
        double nuevaNota = leerNota("\nIngrese la nueva nota (0-20): ");

        if (daoMatricula.modificarNota(codEstudiante, codCurso, nuevaNota)) {
            System.out.println("\nNota modificada correctamente.");
            System.out.println(m);
        }
    }

    // 15. ELIMINAR MATRÍCULA
    public static void eliminarMatricula() {
        System.out.println("\n===== ELIMINAR MATRICULA =====");
        int codEstudiante = leerEntero("Ingrese codigo del estudiante: ");
        int codCurso = leerEntero("Ingrese codigo del curso: ");
        Matricula m = daoMatricula.buscar(codEstudiante, codCurso);
        if (m == null) {
            System.out.println("\nMatricula no encontrada.");
            return;
        }
        System.out.println("\nMatricula encontrada:");
        System.out.println(m);
        String respuesta = leerTexto("\nEsta seguro de eliminarla? (S/N): ");
        if (respuesta.equalsIgnoreCase("S")) {
            if (daoMatricula.eliminar(codEstudiante, codCurso)) {
                System.out.println("\nMatricula eliminada correctamente.");
            }
        } else {
            System.out.println("\nOperacion cancelada.");
        }
    }

    // =====================================================================
    // REPORTES
    // =====================================================================

    // 16. PROMEDIO DE ESTUDIANTE
    public static void promedioEstudiante() {
        System.out.println("\n===== PROMEDIO DEL ESTUDIANTE =====");
        int codigo = leerEntero("Ingrese codigo del estudiante: ");
        Estudiante e = daoEstudiante.buscarPorCodigo(codigo);
        if (e == null) {
            System.out.println("\nEstudiante no encontrado.");
            return;
        }
        if (!e.tieneMatriculas()) {
            System.out.println("\nEl estudiante no tiene notas registradas.");
            return;
        }
        System.out.println("\nEstudiante: " + e.getNombres() + " " + e.getApellidos());
        StringBuilder suma = new StringBuilder();
        for (int i = 0; i < e.getMatriculas().size(); i++) {
            if (i > 0) {
                suma.append(" + ");
            }
            suma.append(String.format("%.2f", e.getMatriculas().get(i).getNotaFinal()));
        }
        System.out.println("Calculo: (" + suma + ") / " + e.getMatriculas().size());
        System.out.println("Promedio: " + String.format("%.2f", e.calcularPromedio()));
    }

    // 17. RANKING ACADÉMICO
    public static void rankingAcademico() {
        System.out.println("\n===== RANKING ACADEMICO =====");
        ArrayList<Estudiante> ranking = daoEstudiante.ranking();
        if (ranking.isEmpty()) {
            System.out.println("No hay estudiantes con notas registradas.");
            return;
        }
        int puesto = 1;
        for (Estudiante e : ranking) {
            System.out.println(puesto + ". " + e.getNombres() + " " + e.getApellidos()
                    + " | Promedio: " + String.format("%.2f", e.calcularPromedio()));
            puesto++;
        }
    }

    // 18. ESTUDIANTES POR CARRERA
    public static void estudiantesPorCarrera() {
        System.out.println("\n===== ESTUDIANTES POR CARRERA =====");
        String carrera = leerTexto("Ingrese carrera: ");
        ArrayList<Estudiante> resultado = daoEstudiante.listarPorCarrera(carrera);
        if (resultado.isEmpty()) {
            System.out.println("\nNo hay estudiantes registrados en esa carrera.");
            return;
        }
        System.out.println("\nEstudiantes de " + carrera + ":");
        for (Estudiante e : resultado) {
            System.out.println(e);
        }
        System.out.println("\nTotal: " + resultado.size());
    }

    // 19. ESTUDIANTES DESAPROBADOS
    public static void estudiantesDesaprobados() {
        System.out.println("\n===== ESTUDIANTES CON CURSOS DESAPROBADOS =====");
        ArrayList<Estudiante> resultado = daoEstudiante.listarDesaprobados();
        if (resultado.isEmpty()) {
            System.out.println("No hay estudiantes con cursos desaprobados.");
            return;
        }
        for (Estudiante e : resultado) {
            System.out.println("\n" + e.getNombres() + " " + e.getApellidos()
                    + " (Codigo: " + e.getCodigo() + ")");
            for (Matricula m : e.getMatriculas()) {
                if (m.getEstado().equals("DESAPROBADO")) {
                    System.out.println("   - " + m.getCurso().getNombre()
                            + " | Nota: " + String.format("%.2f", m.getNotaFinal()));
                }
            }
        }
    }

    // 20. MEJOR PROMEDIO
    public static void mejorPromedio() {
        System.out.println("\n===== ESTUDIANTE CON MAYOR PROMEDIO =====");
        Estudiante mejor = daoEstudiante.mejorPromedio();
        if (mejor == null) {
            System.out.println("No hay estudiantes con notas registradas.");
            return;
        }
        System.out.println("Estudiante: " + mejor.getNombres() + " " + mejor.getApellidos());
        System.out.println("Carrera: " + mejor.getCarrera());
        System.out.println("Promedio: " + String.format("%.2f", mejor.calcularPromedio()));
    }

    // =====================================================================
    // DATOS DE PRUEBA (opcional)
    // =====================================================================
    public static void cargarDatosPrueba() {
        Estudiante e1 = new Estudiante(1001, "70123456", "Juan", "Perez Lopez", 20, "Computacion e Informatica", 3);
        Estudiante e2 = new Estudiante(1002, "71234567", "Maria", "Garcia Ruiz", 21, "Diseno y Programacion Web", 4);
        Estudiante e3 = new Estudiante(1003, "72345678", "Luis", "Torres Vega", 19, "Computacion e Informatica", 2);
        daoEstudiante.agregar(e1);
        daoEstudiante.agregar(e2);
        daoEstudiante.agregar(e3);

        Curso c1 = new Curso(1, "Algoritmos y Estructuras de Datos", 4, "Ing. Ramos");
        Curso c2 = new Curso(2, "Base de Datos", 3, "Ing. Salas");
        Curso c3 = new Curso(3, "Programacion Web", 4, "Ing. Quispe");
        daoCurso.agregar(c1);
        daoCurso.agregar(c2);
        daoCurso.agregar(c3);

        daoMatricula.agregar(e1, c1, 16);
        daoMatricula.agregar(e1, c2, 18);
        daoMatricula.agregar(e1, c3, 14);
        daoMatricula.agregar(e2, c1, 12);
        daoMatricula.agregar(e2, c2, 10);
        daoMatricula.agregar(e3, c1, 9);
        daoMatricula.agregar(e3, c3, 17);
    }
}
